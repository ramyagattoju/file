package com.svk;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] abc){
		ApplicationContext ax = new ClassPathXmlApplicationContext("");
	}
}
